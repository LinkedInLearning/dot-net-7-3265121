#!/bin/sh
echo Bonjour $*
